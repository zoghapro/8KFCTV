package com.fctv.player8k.data;

import com.fctv.player8k.model.Category;
import com.fctv.player8k.model.MediaEntry;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Turns an M3U/M3U8 playlist body into entries plus the categories they imply. */
public class M3uParser {

    public static class Result {
        public final List<MediaEntry> entries = new ArrayList<>();
        public final List<Category> categories = new ArrayList<>();
    }

    public static Result parse(String body) {
        Result result = new Result();
        if (body == null) return result;

        Map<String, Category> cats = new LinkedHashMap<>();
        String[] lines = body.replace("\r", "").split("\n");

        String name = null;
        String logo = "";
        String group = "";
        int autoId = 0;

        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) continue;

            if (line.startsWith("#EXTINF")) {
                int comma = line.lastIndexOf(',');
                name = comma >= 0 ? line.substring(comma + 1).trim() : "Channel";
                logo = attr(line, "tvg-logo");
                group = attr(line, "group-title");
                if (group.isEmpty()) group = "Ungrouped";
                String tvgName = attr(line, "tvg-name");
                if (name.isEmpty() && !tvgName.isEmpty()) name = tvgName;

            } else if (line.startsWith("#")) {
                // #EXTGRP:, #EXTVLCOPT: and friends - not needed for playback here.
                if (line.startsWith("#EXTGRP:")) group = line.substring(8).trim();

            } else if (name != null) {
                MediaEntry e = new MediaEntry(String.valueOf(autoId++), name, guessType(line));
                e.url = line;
                e.logo = logo;
                e.categoryId = group;
                result.entries.add(e);

                Category c = cats.get(group);
                if (c == null) {
                    c = new Category(group, group);
                    cats.put(group, c);
                }
                c.count++;

                name = null;
                logo = "";
            }
        }

        result.categories.addAll(cats.values());
        return result;
    }

    /** M3U has no type field, so infer from the file extension. */
    private static String guessType(String url) {
        String u = url.toLowerCase();
        int q = u.indexOf('?');
        if (q > 0) u = u.substring(0, q);
        if (u.endsWith(".mp4") || u.endsWith(".mkv") || u.endsWith(".avi")) return MediaEntry.MOVIE;
        return MediaEntry.LIVE;
    }

    private static String attr(String line, String key) {
        String needle = key + "=\"";
        int a = line.indexOf(needle);
        if (a < 0) return "";
        a += needle.length();
        int b = line.indexOf('"', a);
        return b > a ? line.substring(a, b) : "";
    }
}

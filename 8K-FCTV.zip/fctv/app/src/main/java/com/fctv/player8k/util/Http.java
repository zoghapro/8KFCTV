package com.fctv.player8k.util;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.zip.GZIPInputStream;

public final class Http {
    public static final String USER_AGENT = "8K-FCTV/1.0 (Android)";
    private static final int CONNECT_TIMEOUT = 15000;
    private static final int READ_TIMEOUT = 30000;
    private static final int MAX_REDIRECTS = 5;

    private Http() {}

    public static String getString(String url) throws Exception {
        InputStream in = open(url, 0);
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"), 16384);
            StringBuilder sb = new StringBuilder();
            char[] buf = new char[8192];
            int n;
            while ((n = r.read(buf)) != -1) sb.append(buf, 0, n);
            return sb.toString();
        } finally {
            closeQuietly(in);
        }
    }

    public static byte[] getBytes(String url) throws Exception {
        InputStream in = open(url, 0);
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toByteArray();
        } finally {
            closeQuietly(in);
        }
    }

    /** Follows redirects manually so http -> https hops are not dropped. */
    private static InputStream open(String url, int depth) throws Exception {
        if (depth > MAX_REDIRECTS) throw new Exception("Too many redirects");
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(CONNECT_TIMEOUT);
        c.setReadTimeout(READ_TIMEOUT);
        c.setInstanceFollowRedirects(false);
        c.setRequestProperty("User-Agent", USER_AGENT);
        c.setRequestProperty("Accept-Encoding", "gzip");

        int code = c.getResponseCode();
        if (code >= 300 && code < 400) {
            String next = c.getHeaderField("Location");
            c.disconnect();
            if (next == null || next.isEmpty()) throw new Exception("Redirect without a target");
            if (next.startsWith("/")) {
                URL base = new URL(url);
                next = base.getProtocol() + "://" + base.getAuthority() + next;
            }
            return open(next, depth + 1);
        }
        if (code >= 400) {
            c.disconnect();
            throw new Exception("Server returned " + code);
        }

        InputStream in = c.getInputStream();
        String enc = c.getContentEncoding();
        if (enc != null && enc.toLowerCase().contains("gzip")) in = new GZIPInputStream(in);
        return in;
    }

    /** URLEncoder.encode(String, Charset) needs API 33, so use the name-based overload. */
    public static String enc(String s) {
        if (s == null) return "";
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    /** Trims whitespace and trailing slashes, and adds http:// when no scheme was typed. */
    public static String normalizeBase(String s) {
        if (s == null) return "";
        s = s.trim();
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        if (s.isEmpty()) return "";
        String lower = s.toLowerCase();
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) s = "http://" + s;
        return s;
    }

    private static void closeQuietly(InputStream in) {
        if (in != null) {
            try { in.close(); } catch (Exception ignored) {}
        }
    }
}

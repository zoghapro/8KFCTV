package com.fctv.player8k.model;

/** One playable thing: a live channel, a movie, or a series header. */
public class MediaEntry {
    public static final String LIVE = "live";
    public static final String MOVIE = "movie";
    public static final String SERIES = "series";

    public String id;          // stream_id / series_id, or the URL hash for M3U
    public String name;
    public String type;
    public String url;         // empty for SERIES (resolved per-episode)
    public String logo;
    public String categoryId;
    public String plot = "";
    public String rating = "";
    public String releaseDate = "";
    public String genre = "";
    public String cast = "";
    public String duration = "";
    public int episodeRunTimeMinutes;

    public MediaEntry(String id, String name, String type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }

    /** Stable key for favorites and resume points, scoped to its playlist. */
    public String key(String playlistId) {
        return playlistId + "|" + type + "|" + id;
    }
}

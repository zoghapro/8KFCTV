package com.fctv.player8k.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fctv.player8k.R;
import com.fctv.player8k.data.Repo;
import com.fctv.player8k.data.Store;
import com.fctv.player8k.model.Episode;
import com.fctv.player8k.model.MediaEntry;
import com.fctv.player8k.model.SeriesDetail;
import com.fctv.player8k.ui.adapter.Click;
import com.fctv.player8k.ui.adapter.EpisodeAdapter;
import com.fctv.player8k.ui.adapter.SeasonAdapter;
import com.fctv.player8k.util.Fmt;
import com.fctv.player8k.util.Task;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Movie details with resume, or a series with its seasons and episodes. */
public class DetailActivity extends Activity {

    public static final String EXTRA_ID = "id";
    public static final String EXTRA_TYPE = "type";

    private MediaEntry entry;
    private SeriesDetail seriesDetail;
    private EpisodeAdapter episodeAdapter;
    private SeasonAdapter seasonAdapter;
    private Store store;

    private TextView status;
    private Button play, restart, fav;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_detail);
        store = Store.get(this);

        String id = getIntent().getStringExtra(EXTRA_ID);
        String type = getIntent().getStringExtra(EXTRA_TYPE);
        entry = Repo.get().findById(type, id);

        if (entry == null) {
            Toast.makeText(this, "That title is no longer in the list", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        status = findViewById(R.id.de_status);
        play = findViewById(R.id.de_play);
        restart = findViewById(R.id.de_restart);
        fav = findViewById(R.id.de_fav);

        bindHeader();

        if (MediaEntry.SERIES.equals(entry.type)) setUpSeries();
        else setUpMovie();

        fav.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleFavorite(); }
        });
        updateFavoriteLabel();
    }

    private void bindHeader() {
        ((TextView) findViewById(R.id.de_title)).setText(entry.name);

        ImageView poster = findViewById(R.id.de_poster);
        if (entry.logo != null && !entry.logo.isEmpty()) {
            Glide.with(this).load(entry.logo)
                    .placeholder(R.drawable.bg_poster_placeholder)
                    .error(R.drawable.bg_poster_placeholder)
                    .centerCrop().into(poster);
        }
        bindMeta();
    }

    private void bindMeta() {
        List<String> bits = new ArrayList<>();
        if (!Fmt.isBlank(entry.releaseDate)) bits.add(entry.releaseDate.trim());
        if (!Fmt.isBlank(entry.genre)) bits.add(entry.genre.trim());
        if (!Fmt.isBlank(entry.rating)) bits.add(entry.rating.trim() + "/10");
        if (!Fmt.isBlank(entry.duration)) bits.add(entry.duration.trim());

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bits.size(); i++) {
            if (i > 0) sb.append("  ·  ");
            sb.append(bits.get(i));
        }
        ((TextView) findViewById(R.id.de_meta)).setText(sb.toString());
        ((TextView) findViewById(R.id.de_plot))
                .setText(Fmt.isBlank(entry.plot) ? "No description available." : entry.plot);
    }

    // ---------- movie ----------

    private void setUpMovie() {
        final String key = entry.key(Repo.get().active().id);
        final long resumeAt = store.resume(key);

        play.setText(resumeAt > 0
                ? getString(R.string.resume) + "  " + Fmt.duration(resumeAt)
                : getString(R.string.play));
        restart.setVisibility(resumeAt > 0 ? View.VISIBLE : View.GONE);

        play.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { playMovie(resumeAt); }
        });
        restart.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                store.clearResume(key);
                playMovie(0);
            }
        });
        play.requestFocus();

        // Listing endpoints omit plot and cast, so fetch the full record.
        if (Repo.get().xtream() != null && Fmt.isBlank(entry.plot)) {
            Task.run(new Task.Work<Boolean>() {
                @Override public Boolean run() {
                    Repo.get().xtream().enrichMovie(entry);
                    return Boolean.TRUE;
                }
            }, new Task.Done<Boolean>() {
                @Override public void onSuccess(Boolean ignored) { bindHeader(); }
                @Override public void onError(Exception e) { /* metadata only */ }
            });
        }
    }

    private void playMovie(long resumeAt) {
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra(PlayerActivity.EXTRA_URL, entry.url);
        i.putExtra(PlayerActivity.EXTRA_TITLE, entry.name);
        i.putExtra(PlayerActivity.EXTRA_LOGO, entry.logo);
        i.putExtra(PlayerActivity.EXTRA_LIVE, false);
        i.putExtra(PlayerActivity.EXTRA_RESUME_KEY, entry.key(Repo.get().active().id));
        i.putExtra(PlayerActivity.EXTRA_RESUME_AT, resumeAt);
        startActivity(i);
    }

    // ---------- series ----------

    private void setUpSeries() {
        play.setVisibility(View.GONE);
        restart.setVisibility(View.GONE);
        findViewById(R.id.de_season_bar).setVisibility(View.VISIBLE);

        RecyclerView seasons = findViewById(R.id.de_seasons);
        seasons.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        seasonAdapter = new SeasonAdapter(new Click<Integer>() {
            @Override public void on(Integer season, int position) { showSeason(season); }
        });
        seasons.setAdapter(seasonAdapter);

        RecyclerView episodes = findViewById(R.id.de_episodes);
        episodes.setLayoutManager(new LinearLayoutManager(this));
        episodeAdapter = new EpisodeAdapter(new Click<Episode>() {
            @Override public void on(Episode ep, int position) { playEpisode(ep); }
        });
        episodes.setAdapter(episodeAdapter);
        episodes.setVisibility(View.VISIBLE);

        if (Repo.get().xtream() == null) {
            status.setVisibility(View.VISIBLE);
            status.setText("Series need an Xtream Codes playlist.");
            return;
        }

        status.setVisibility(View.VISIBLE);
        status.setText(R.string.loading);

        Task.run(new Task.Work<SeriesDetail>() {
            @Override public SeriesDetail run() throws Exception {
                return Repo.get().xtream().seriesDetail(entry.id);
            }
        }, new Task.Done<SeriesDetail>() {
            @Override public void onSuccess(SeriesDetail detail) {
                seriesDetail = detail;
                status.setVisibility(View.GONE);

                if (!Fmt.isBlank(detail.plot)) entry.plot = detail.plot;
                if (!Fmt.isBlank(detail.genre)) entry.genre = detail.genre;
                if (!Fmt.isBlank(detail.rating)) entry.rating = detail.rating;
                if (!Fmt.isBlank(detail.releaseDate)) entry.releaseDate = detail.releaseDate;
                bindMeta();

                List<Integer> numbers = detail.seasonNumbers();
                if (numbers.isEmpty()) {
                    status.setVisibility(View.VISIBLE);
                    status.setText("No episodes listed for this series.");
                    return;
                }
                seasonAdapter.submit(numbers);
                showSeason(numbers.get(0));
            }
            @Override public void onError(Exception e) {
                status.setVisibility(View.VISIBLE);
                status.setText(Repo.readable(e));
            }
        });
    }

    private void showSeason(int season) {
        if (seriesDetail == null) return;
        Set<String> resumeKeys = new HashSet<>();
        String pid = Repo.get().active().id;
        for (Episode ep : seriesDetail.episodesOf(season)) {
            if (store.resume(ep.key(pid, entry.id)) > 0) resumeKeys.add(ep.key(pid, entry.id));
        }
        episodeAdapter.setResumeContext(pid, entry.id, resumeKeys);
        episodeAdapter.submit(seriesDetail.episodesOf(season));
    }

    private void playEpisode(Episode ep) {
        String key = ep.key(Repo.get().active().id, entry.id);
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra(PlayerActivity.EXTRA_URL, ep.url);
        i.putExtra(PlayerActivity.EXTRA_TITLE, entry.name + " — " + ep.label());
        i.putExtra(PlayerActivity.EXTRA_LOGO, Fmt.isBlank(ep.cover) ? entry.logo : ep.cover);
        i.putExtra(PlayerActivity.EXTRA_LIVE, false);
        i.putExtra(PlayerActivity.EXTRA_RESUME_KEY, key);
        i.putExtra(PlayerActivity.EXTRA_RESUME_AT, store.resume(key));
        startActivity(i);
    }

    // ---------- favorites ----------

    private void toggleFavorite() {
        store.toggleFavorite(entry.key(Repo.get().active().id));
        updateFavoriteLabel();
    }

    private void updateFavoriteLabel() {
        boolean saved = store.isFavorite(entry.key(Repo.get().active().id));
        fav.setText(saved ? "Remove from favorites" : "Add to favorites");
    }

    @Override protected void onResume() {
        super.onResume();
        if (entry != null && !MediaEntry.SERIES.equals(entry.type)) setUpMovie();
        if (entry != null && MediaEntry.SERIES.equals(entry.type) && seriesDetail != null) {
            List<Integer> numbers = seriesDetail.seasonNumbers();
            if (!numbers.isEmpty()) showSeason(numbers.get(0));
        }
    }
}

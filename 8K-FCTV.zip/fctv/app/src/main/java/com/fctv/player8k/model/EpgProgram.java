package com.fctv.player8k.model;

public class EpgProgram {
    public String title = "";
    public String description = "";
    public long startMillis;
    public long endMillis;

    public boolean isNow(long at) {
        return startMillis <= at && at < endMillis;
    }

    /** 0..1 through the programme, for the progress bar. */
    public float progressAt(long at) {
        long span = endMillis - startMillis;
        if (span <= 0) return 0f;
        float p = (at - startMillis) / (float) span;
        return Math.max(0f, Math.min(1f, p));
    }
}

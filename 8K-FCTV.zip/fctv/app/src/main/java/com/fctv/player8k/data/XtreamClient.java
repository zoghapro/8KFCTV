package com.fctv.player8k.data;

import com.fctv.player8k.model.Category;
import com.fctv.player8k.model.EpgProgram;
import com.fctv.player8k.model.Episode;
import com.fctv.player8k.model.MediaEntry;
import com.fctv.player8k.model.Playlist;
import com.fctv.player8k.model.SeriesDetail;
import com.fctv.player8k.util.Http;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/** Talks to a standard Xtream Codes panel (player_api.php). */
public class XtreamClient {

    private final String base;
    private final String user;
    private final String pass;

    public XtreamClient(Playlist p) {
        this.base = Http.normalizeBase(p.server);
        this.user = p.username == null ? "" : p.username.trim();
        this.pass = p.password == null ? "" : p.password.trim();
    }

    private String api(String action, String extra) {
        StringBuilder sb = new StringBuilder(base)
                .append("/player_api.php?username=").append(Http.enc(user))
                .append("&password=").append(Http.enc(pass));
        if (action != null && !action.isEmpty()) sb.append("&action=").append(action);
        if (extra != null && !extra.isEmpty()) sb.append(extra);
        return sb.toString();
    }

    /** @return a human-readable expiry label. Throws when the account is not usable. */
    public String authenticate() throws Exception {
        String body = Http.getString(api(null, null));
        JSONObject root = new JSONObject(body);
        JSONObject info = root.optJSONObject("user_info");
        if (info == null) throw new Exception("That server did not return an Xtream account");

        String status = info.optString("status", "");
        if (!"Active".equalsIgnoreCase(status)) {
            throw new Exception("Account status: " + (status.isEmpty() ? "unknown" : status));
        }

        String exp = info.optString("exp_date", "");
        if (exp.isEmpty() || "null".equals(exp)) return "No expiry";
        try {
            long millis = Long.parseLong(exp) * 1000L;
            return "Expires " + com.fctv.player8k.util.Fmt.day(millis);
        } catch (NumberFormatException e) {
            return "";
        }
    }

    // ---------- categories ----------

    public List<Category> categories(String type) throws Exception {
        String action = MediaEntry.LIVE.equals(type) ? "get_live_categories"
                : MediaEntry.MOVIE.equals(type) ? "get_vod_categories"
                : "get_series_categories";
        List<Category> out = new ArrayList<>();
        JSONArray a = new JSONArray(Http.getString(api(action, null)));
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            out.add(new Category(o.optString("category_id"), o.optString("category_name", "Unnamed")));
        }
        return out;
    }

    // ---------- listings ----------

    public List<MediaEntry> streams(String type) throws Exception {
        String action = MediaEntry.LIVE.equals(type) ? "get_live_streams"
                : MediaEntry.MOVIE.equals(type) ? "get_vod_streams"
                : "get_series";
        List<MediaEntry> out = new ArrayList<>();
        JSONArray a = new JSONArray(Http.getString(api(action, null)));

        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;

            String name = o.optString("name", o.optString("title", "Untitled"));

            if (MediaEntry.SERIES.equals(type)) {
                MediaEntry e = new MediaEntry(o.optString("series_id"), name, MediaEntry.SERIES);
                e.logo = o.optString("cover", "");
                e.categoryId = o.optString("category_id");
                e.plot = o.optString("plot", "");
                e.rating = o.optString("rating", "");
                e.genre = o.optString("genre", "");
                e.releaseDate = o.optString("releaseDate", o.optString("release_date", ""));
                e.cast = o.optString("cast", "");
                out.add(e);
            } else {
                String id = o.optString("stream_id");
                boolean live = MediaEntry.LIVE.equals(type);
                String ext = o.optString("container_extension", live ? "ts" : "mp4");
                MediaEntry e = new MediaEntry(id, name, type);
                e.url = base + (live ? "/live/" : "/movie/") + Http.enc(user) + "/" + Http.enc(pass)
                        + "/" + id + "." + ext;
                e.logo = o.optString("stream_icon", o.optString("cover", ""));
                e.categoryId = o.optString("category_id");
                e.rating = o.optString("rating", "");
                out.add(e);
            }
        }
        return out;
    }

    /** Extra VOD metadata (plot, cast, runtime) that the listing endpoint omits. */
    public void enrichMovie(MediaEntry entry) {
        try {
            JSONObject root = new JSONObject(Http.getString(api("get_vod_info", "&vod_id=" + Http.enc(entry.id))));
            JSONObject info = root.optJSONObject("info");
            if (info == null) return;
            entry.plot = info.optString("plot", info.optString("description", entry.plot));
            entry.cast = info.optString("cast", entry.cast);
            entry.genre = info.optString("genre", entry.genre);
            entry.rating = info.optString("rating", entry.rating);
            entry.duration = info.optString("duration", entry.duration);
            entry.releaseDate = info.optString("releasedate", info.optString("releaseDate", entry.releaseDate));
            String poster = info.optString("movie_image", "");
            if (!poster.isEmpty()) entry.logo = poster;
        } catch (Exception ignored) {
            // Metadata is a nice-to-have; playback does not depend on it.
        }
    }

    // ---------- series ----------

    public SeriesDetail seriesDetail(String seriesId) throws Exception {
        SeriesDetail detail = new SeriesDetail();
        JSONObject root = new JSONObject(Http.getString(api("get_series_info", "&series_id=" + Http.enc(seriesId))));

        JSONObject info = root.optJSONObject("info");
        if (info != null) {
            detail.plot = info.optString("plot", "");
            detail.cover = info.optString("cover", "");
            detail.cast = info.optString("cast", "");
            detail.genre = info.optString("genre", "");
            detail.releaseDate = info.optString("releaseDate", info.optString("release_date", ""));
            detail.rating = info.optString("rating", "");
        }

        JSONObject episodes = root.optJSONObject("episodes");
        if (episodes == null) return detail;

        // Season keys arrive as strings and are not always in order.
        List<Integer> seasonNumbers = new ArrayList<>();
        Iterator<String> keys = episodes.keys();
        while (keys.hasNext()) {
            try { seasonNumbers.add(Integer.parseInt(keys.next())); } catch (NumberFormatException ignored) {}
        }
        java.util.Collections.sort(seasonNumbers);

        for (Integer season : seasonNumbers) {
            JSONArray arr = episodes.optJSONArray(String.valueOf(season));
            if (arr == null) continue;
            List<Episode> list = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                Episode ep = new Episode();
                ep.id = o.optString("id");
                ep.title = o.optString("title", "Episode " + (i + 1));
                ep.season = season;
                ep.number = o.optInt("episode_num", i + 1);
                String ext = o.optString("container_extension", "mp4");
                ep.url = base + "/series/" + Http.enc(user) + "/" + Http.enc(pass) + "/" + ep.id + "." + ext;

                JSONObject epInfo = o.optJSONObject("info");
                if (epInfo != null) {
                    ep.plot = epInfo.optString("plot", "");
                    ep.cover = epInfo.optString("movie_image", "");
                    ep.durationSeconds = epInfo.optInt("duration_secs", 0);
                }
                list.add(ep);
            }
            detail.seasons.put(season, list);
        }
        return detail;
    }

    // ---------- EPG ----------

    /** Now/next for one channel. Xtream returns base64 title and description. */
    public List<EpgProgram> shortEpg(String streamId) throws Exception {
        List<EpgProgram> out = new ArrayList<>();
        JSONObject root = new JSONObject(
                Http.getString(api("get_short_epg", "&stream_id=" + Http.enc(streamId) + "&limit=2")));
        JSONArray arr = root.optJSONArray("epg_listings");
        if (arr == null) return out;

        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            EpgProgram p = new EpgProgram();
            p.title = decode(o.optString("title", ""));
            p.description = decode(o.optString("description", ""));
            p.startMillis = o.optLong("start_timestamp", 0) * 1000L;
            p.endMillis = o.optLong("stop_timestamp", 0) * 1000L;
            if (p.endMillis > 0) out.add(p);
        }
        return out;
    }

    private static String decode(String maybeBase64) {
        if (maybeBase64 == null || maybeBase64.isEmpty()) return "";
        try {
            byte[] data = android.util.Base64.decode(maybeBase64, android.util.Base64.DEFAULT);
            String s = new String(data, "UTF-8");
            return s.trim().isEmpty() ? maybeBase64 : s;
        } catch (Exception e) {
            return maybeBase64;
        }
    }

    /** Some panels serve .m3u8 rather than .ts for live; used as a playback fallback. */
    public static String alternateLiveUrl(String url) {
        if (url == null) return null;
        String lower = url.toLowerCase(Locale.US);
        if (lower.endsWith(".ts")) return url.substring(0, url.length() - 3) + ".m3u8";
        if (lower.endsWith(".m3u8")) return url.substring(0, url.length() - 5) + ".ts";
        return null;
    }
}

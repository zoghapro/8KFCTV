package com.fctv.player8k.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fctv.player8k.R;
import com.fctv.player8k.data.Repo;
import com.fctv.player8k.data.Store;
import com.fctv.player8k.data.XtreamClient;
import com.fctv.player8k.model.Playlist;
import com.fctv.player8k.ui.adapter.Click;
import com.fctv.player8k.ui.adapter.PlaylistAdapter;
import com.fctv.player8k.util.Fmt;
import com.fctv.player8k.util.Http;
import com.fctv.player8k.util.Task;

import java.util.List;

/** Add, choose and remove playlists. */
public class PlaylistsActivity extends Activity {

    private PlaylistAdapter adapter;
    private View empty;
    private Store store;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_playlists);
        store = Store.get(this);
        empty = findViewById(R.id.playlist_empty);

        RecyclerView list = findViewById(R.id.playlist_list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new PlaylistAdapter(
                new Click<Playlist>() {
                    @Override public void on(Playlist p, int position) { choose(p); }
                },
                new Click<Playlist>() {
                    @Override public void on(Playlist p, int position) { confirmDelete(p); }
                });
        list.setAdapter(adapter);

        findViewById(R.id.playlist_add).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showDialog(); }
        });

        refresh();
    }

    private void refresh() {
        List<Playlist> all = store.playlists();
        adapter.submit(all);
        empty.setVisibility(all.isEmpty() ? View.VISIBLE : View.GONE);
        if (all.isEmpty()) findViewById(R.id.playlist_add).requestFocus();
    }

    private void choose(Playlist p) {
        store.setActivePlaylist(p.id);
        Repo.get().setActive(p);
        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }

    private void confirmDelete(final Playlist p) {
        new AlertDialog.Builder(this)
                .setTitle("Remove this playlist?")
                .setMessage("Its favorites and resume points go with it. The source itself is untouched.")
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        store.deletePlaylist(p.id);
                        refresh();
                    }
                })
                .show();
    }

    // ---------- add dialog ----------

    private void showDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_playlist, null, false);

        final Button tabXtream = view.findViewById(R.id.tab_xtream);
        final Button tabM3u = view.findViewById(R.id.tab_m3u);
        final View groupXtream = view.findViewById(R.id.group_xtream);
        final View groupM3u = view.findViewById(R.id.group_m3u);
        final EditText inName = view.findViewById(R.id.in_name);
        final EditText inServer = view.findViewById(R.id.in_server);
        final EditText inUser = view.findViewById(R.id.in_user);
        final EditText inPass = view.findViewById(R.id.in_pass);
        final EditText inM3u = view.findViewById(R.id.in_m3u);
        final TextView status = view.findViewById(R.id.dialog_status);
        final Button save = view.findViewById(R.id.btn_save);
        final Button cancel = view.findViewById(R.id.btn_cancel);

        final boolean[] isXtream = { true };

        final AlertDialog dialog = new AlertDialog.Builder(this).setView(view).create();

        tabXtream.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                isXtream[0] = true;
                groupXtream.setVisibility(View.VISIBLE);
                groupM3u.setVisibility(View.GONE);
                tabXtream.setBackgroundResource(R.drawable.bg_button_primary);
                tabM3u.setBackgroundResource(R.drawable.bg_button_ghost);
            }
        });
        tabM3u.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                isXtream[0] = false;
                groupXtream.setVisibility(View.GONE);
                groupM3u.setVisibility(View.VISIBLE);
                tabM3u.setBackgroundResource(R.drawable.bg_button_primary);
                tabXtream.setBackgroundResource(R.drawable.bg_button_ghost);
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { dialog.dismiss(); }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final Playlist p = new Playlist();
                p.name = inName.getText().toString().trim();

                if (isXtream[0]) {
                    p.type = Playlist.TYPE_XTREAM;
                    p.server = Http.normalizeBase(inServer.getText().toString());
                    p.username = inUser.getText().toString().trim();
                    p.password = inPass.getText().toString().trim();
                    if (Fmt.isBlank(p.server) || Fmt.isBlank(p.username) || Fmt.isBlank(p.password)) {
                        show(status, "Fill in the server, username and password.");
                        return;
                    }
                    if (p.name.isEmpty()) p.name = hostLabel(p.server);
                } else {
                    p.type = Playlist.TYPE_M3U;
                    p.m3uUrl = inM3u.getText().toString().trim();
                    if (Fmt.isBlank(p.m3uUrl)) {
                        show(status, "Paste the M3U address first.");
                        return;
                    }
                    if (p.name.isEmpty()) p.name = hostLabel(p.m3uUrl);
                }

                save.setEnabled(false);
                show(status, "Checking…");
                verify(p, status, save, dialog);
            }
        });

        dialog.show();
        inName.requestFocus();
    }

    /** Confirm the source works before saving, so failures surface here and not later. */
    private void verify(final Playlist p, final TextView status,
                        final Button save, final AlertDialog dialog) {
        Task.run(new Task.Work<String>() {
            @Override public String run() throws Exception {
                if (p.isXtream()) {
                    return new XtreamClient(p).authenticate();
                }
                String body = Http.getString(p.m3uUrl);
                if (!body.contains("#EXTM3U") && !body.contains("#EXTINF")) {
                    throw new Exception("That address did not return an M3U playlist");
                }
                return "";
            }
        }, new Task.Done<String>() {
            @Override public void onSuccess(String expiry) {
                p.expiryLabel = expiry == null ? "" : expiry;
                store.savePlaylist(p);
                store.setActivePlaylist(p.id);
                Repo.get().setActive(p);
                dialog.dismiss();
                Toast.makeText(PlaylistsActivity.this, "Playlist added", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(PlaylistsActivity.this, HomeActivity.class));
                finish();
            }
            @Override public void onError(Exception e) {
                save.setEnabled(true);
                show(status, Repo.readable(e));
            }
        });
    }

    private static void show(TextView status, String message) {
        status.setText(message);
        status.setVisibility(View.VISIBLE);
    }

    private static String hostLabel(String url) {
        try {
            java.net.URL u = new java.net.URL(url.startsWith("http") ? url : "http://" + url);
            return u.getHost();
        } catch (Exception e) {
            return "Playlist";
        }
    }
}

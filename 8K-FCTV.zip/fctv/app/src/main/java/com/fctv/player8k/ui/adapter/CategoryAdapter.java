package com.fctv.player8k.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fctv.player8k.R;
import com.fctv.player8k.model.Category;

import java.util.ArrayList;
import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.VH> {

    private final List<Category> items = new ArrayList<>();
    private final Click<Category> onClick;
    private int selected = 0;

    public CategoryAdapter(Click<Category> onClick) {
        this.onClick = onClick;
    }

    public void submit(List<Category> list) {
        items.clear();
        if (list != null) items.addAll(list);
        selected = 0;
        notifyDataSetChanged();
    }

    public void setSelected(int position) {
        int old = selected;
        selected = position;
        notifyItemChanged(old);
        notifyItemChanged(position);
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final Category c = items.get(position);
        h.name.setText(c.name);
        h.count.setText(c.count > 0 ? String.valueOf(c.count) : "");
        h.itemView.setSelected(position == selected);
        h.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int pos = h.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) return;
                setSelected(pos);
                onClick.on(c, pos);
            }
        });
        // On a remote, moving focus is the same gesture as selecting.
        h.itemView.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) return;
                int pos = h.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION || pos == selected) return;
                setSelected(pos);
                onClick.on(c, pos);
            }
        });
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView name, count;
        VH(View v) {
            super(v);
            name = v.findViewById(R.id.cat_name);
            count = v.findViewById(R.id.cat_count);
        }
    }
}

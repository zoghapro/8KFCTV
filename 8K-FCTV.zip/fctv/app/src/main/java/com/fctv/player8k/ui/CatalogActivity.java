package com.fctv.player8k.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fctv.player8k.R;
import com.fctv.player8k.data.Repo;
import com.fctv.player8k.data.Store;
import com.fctv.player8k.model.Category;
import com.fctv.player8k.model.MediaEntry;
import com.fctv.player8k.ui.adapter.CategoryAdapter;
import com.fctv.player8k.ui.adapter.ChannelAdapter;
import com.fctv.player8k.ui.adapter.Click;
import com.fctv.player8k.ui.adapter.PosterAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Category sidebar plus content. Live channels use a list, movies and series a
 * poster grid. One screen serves all three sections.
 */
public class CatalogActivity extends Activity {

    public static final String EXTRA_TYPE = "type";
    public static final String EXTRA_FAVORITES = "favorites_only";

    private String type = MediaEntry.LIVE;
    private boolean favoritesOnly;
    private String categoryId = Category.ALL_ID;
    private String query = "";

    private Store store;
    private CategoryAdapter categoryAdapter;
    private ChannelAdapter channelAdapter;
    private PosterAdapter posterAdapter;
    private RecyclerView content;
    private TextView message;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_catalog);
        store = Store.get(this);

        type = getIntent().getStringExtra(EXTRA_TYPE);
        if (type == null) type = MediaEntry.LIVE;
        favoritesOnly = getIntent().getBooleanExtra(EXTRA_FAVORITES, false);

        TextView title = findViewById(R.id.catalog_title);
        title.setText(favoritesOnly ? getString(R.string.favorites) : sectionName());

        message = findViewById(R.id.catalog_message);
        content = findViewById(R.id.catalog_content);

        setUpCategories();
        setUpContent();
        setUpSearch();

        load();
    }

    private String sectionName() {
        if (MediaEntry.MOVIE.equals(type)) return getString(R.string.movies);
        if (MediaEntry.SERIES.equals(type)) return getString(R.string.series);
        return getString(R.string.live_tv);
    }

    private boolean isGrid() {
        return MediaEntry.MOVIE.equals(type) || MediaEntry.SERIES.equals(type);
    }

    private void setUpCategories() {
        RecyclerView categories = findViewById(R.id.catalog_categories);
        categories.setLayoutManager(new LinearLayoutManager(this));
        categoryAdapter = new CategoryAdapter(new Click<Category>() {
            @Override public void on(Category c, int position) {
                if (store.isLocked(c.id)) {
                    askPin(c.id);
                    return;
                }
                categoryId = c.id;
                render();
            }
        });
        categories.setAdapter(categoryAdapter);
        if (favoritesOnly) categories.setVisibility(View.GONE);
    }

    private void setUpContent() {
        if (isGrid()) {
            content.setLayoutManager(new GridLayoutManager(this, gridColumns()));
            posterAdapter = new PosterAdapter(new Click<MediaEntry>() {
                @Override public void on(MediaEntry e, int position) { openDetail(e); }
            });
            content.setAdapter(posterAdapter);
        } else {
            content.setLayoutManager(new LinearLayoutManager(this));
            channelAdapter = new ChannelAdapter(
                    new Click<MediaEntry>() {
                        @Override public void on(MediaEntry e, int position) { playLive(e, position); }
                    },
                    new Click<MediaEntry>() {
                        @Override public void on(MediaEntry e, int position) { toggleFavorite(e); }
                    });
            content.setAdapter(channelAdapter);
        }
    }

    /** Poster width plus padding, against the space left after the sidebar. */
    private int gridColumns() {
        float density = getResources().getDisplayMetrics().density;
        int screen = getResources().getDisplayMetrics().widthPixels;
        int sidebar = (int) (getResources().getDimension(R.dimen.sidebar_width));
        int padding = (int) (getResources().getDimension(R.dimen.screen_pad) * 2 + 16 * density);
        int available = screen - sidebar - padding;
        int cell = (int) (getResources().getDimension(R.dimen.poster_width) + 16 * density);
        return Math.max(2, available / Math.max(1, cell));
    }

    private void setUpSearch() {
        EditText search = findViewById(R.id.catalog_search);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                query = s.toString();
                render();
            }
        });
    }

    private void load() {
        message.setVisibility(View.VISIBLE);
        message.setText(R.string.loading);

        Repo.get().load(this, type, new Repo.Loaded() {
            @Override public void ok() {
                buildCategoryList();
                render();
            }
            @Override public void fail(String msg) {
                message.setVisibility(View.VISIBLE);
                message.setText(msg);
            }
        });
    }

    private void buildCategoryList() {
        List<Category> cats = new ArrayList<>();
        Category all = new Category(Category.ALL_ID, "All");
        all.count = Repo.get().entries(type).size();
        cats.add(all);
        cats.addAll(Repo.get().categories(type));
        categoryAdapter.submit(cats);
    }

    private void render() {
        List<MediaEntry> data = favoritesOnly
                ? Repo.get().favorites(type, store.favorites())
                : Repo.get().filter(type, categoryId, query);

        if (data.isEmpty()) {
            message.setVisibility(View.VISIBLE);
            message.setText(query.isEmpty() ? R.string.empty_category : R.string.no_results);
        } else {
            message.setVisibility(View.GONE);
        }

        if (isGrid()) {
            posterAdapter.submit(data);
        } else {
            String pid = Repo.get().active() != null ? Repo.get().active().id : "";
            channelAdapter.setFavorites(pid, store.favorites());
            channelAdapter.submit(data);
        }
    }

    // ---------- actions ----------

    private void playLive(MediaEntry entry, int position) {
        // The visible list becomes the zap order inside the player.
        Repo.get().setPlaybackQueue(channelAdapter.items());

        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra(PlayerActivity.EXTRA_URL, entry.url);
        i.putExtra(PlayerActivity.EXTRA_TITLE, entry.name);
        i.putExtra(PlayerActivity.EXTRA_LOGO, entry.logo);
        i.putExtra(PlayerActivity.EXTRA_STREAM_ID, entry.id);
        i.putExtra(PlayerActivity.EXTRA_LIVE, true);
        i.putExtra(PlayerActivity.EXTRA_QUEUE_INDEX, position);
        startActivity(i);
    }

    private void openDetail(MediaEntry entry) {
        Intent i = new Intent(this, DetailActivity.class);
        i.putExtra(DetailActivity.EXTRA_ID, entry.id);
        i.putExtra(DetailActivity.EXTRA_TYPE, entry.type);
        startActivity(i);
    }

    private void toggleFavorite(MediaEntry entry) {
        if (Repo.get().active() == null) return;
        String key = entry.key(Repo.get().active().id);
        store.toggleFavorite(key);
        Toast.makeText(this,
                store.isFavorite(key) ? "Added to favorites" : "Removed from favorites",
                Toast.LENGTH_SHORT).show();
        render();
    }

    private void askPin(final String unlockCategoryId) {
        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setHint("4-digit PIN");

        new AlertDialog.Builder(this)
                .setTitle("This category is locked")
                .setView(input)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton("Unlock", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        if (store.pin().equals(input.getText().toString())) {
                            categoryId = unlockCategoryId;
                            render();
                        } else {
                            Toast.makeText(CatalogActivity.this, "Wrong PIN", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .show();
    }

    @Override protected void onResume() {
        super.onResume();
        // Favorites may have changed in the player or a detail screen.
        if (Repo.get().isLoaded(type)) render();
    }
}

package com.fctv.player8k.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fctv.player8k.R;
import com.fctv.player8k.model.MediaEntry;

import java.util.ArrayList;
import java.util.List;

/** Grid card used for movies and series. */
public class PosterAdapter extends RecyclerView.Adapter<PosterAdapter.VH> {

    private final List<MediaEntry> items = new ArrayList<>();
    private final Click<MediaEntry> onClick;

    public PosterAdapter(Click<MediaEntry> onClick) {
        this.onClick = onClick;
    }

    public void submit(List<MediaEntry> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_poster, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final MediaEntry e = items.get(position);
        h.name.setText(e.name);

        if (e.logo != null && !e.logo.isEmpty()) {
            Glide.with(h.image.getContext())
                    .load(e.logo)
                    .placeholder(R.drawable.bg_poster_placeholder)
                    .error(R.drawable.bg_poster_placeholder)
                    .centerCrop()
                    .into(h.image);
        } else {
            Glide.with(h.image.getContext()).clear(h.image);
            h.image.setImageDrawable(null);
        }

        h.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int pos = h.getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) onClick.on(e, pos);
            }
        });
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView name;
        final ImageView image;
        VH(View v) {
            super(v);
            name = v.findViewById(R.id.po_name);
            image = v.findViewById(R.id.po_image);
        }
    }
}

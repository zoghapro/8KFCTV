package com.fctv.player8k.util;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Minimal background-work helper. Avoids AsyncTask (deprecated) and keeps the
 * app free of a full reactive stack.
 */
public final class Task {
    private static final ExecutorService POOL = Executors.newFixedThreadPool(4);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private Task() {}

    public interface Work<T> { T run() throws Exception; }

    public interface Done<T> {
        void onSuccess(T result);
        void onError(Exception e);
    }

    public static <T> void run(final Work<T> work, final Done<T> done) {
        POOL.execute(new Runnable() {
            @Override public void run() {
                try {
                    final T result = work.run();
                    MAIN.post(new Runnable() {
                        @Override public void run() { done.onSuccess(result); }
                    });
                } catch (final Exception e) {
                    MAIN.post(new Runnable() {
                        @Override public void run() { done.onError(e); }
                    });
                }
            }
        });
    }

    public static void onMain(Runnable r) { MAIN.post(r); }
}

package com.fctv.player8k.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.fctv.player8k.R;
import com.fctv.player8k.data.Repo;
import com.fctv.player8k.data.Store;
import com.fctv.player8k.model.Playlist;

public class SettingsActivity extends Activity {

    private Store store;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);
        store = Store.get(this);

        final EditText pin = findViewById(R.id.set_pin);
        pin.setText(store.pin());

        findViewById(R.id.set_pin_save).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String value = pin.getText().toString().trim();
                if (!value.isEmpty() && value.length() != 4) {
                    Toast.makeText(SettingsActivity.this, "Use exactly 4 digits", Toast.LENGTH_SHORT).show();
                    return;
                }
                store.setPin(value);
                Toast.makeText(SettingsActivity.this,
                        value.isEmpty() ? "PIN turned off" : "PIN saved", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.set_refresh).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Repo.get().invalidate();
                Toast.makeText(SettingsActivity.this,
                        "Playlist will reload next time you open a section", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.set_clear_resume).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                store.clearAllResume();
                Toast.makeText(SettingsActivity.this, "Resume points cleared", Toast.LENGTH_SHORT).show();
            }
        });

        Playlist p = Repo.get().active();
        String name = p == null ? "none" : p.name;
        String kind = p == null ? "" : (p.isXtream() ? "Xtream Codes" : "M3U");
        ((TextView) findViewById(R.id.set_about)).setText(
                getString(R.string.app_name) + " 1.0\n"
                        + "Active playlist: " + name + (kind.isEmpty() ? "" : "  (" + kind + ")"));
    }
}

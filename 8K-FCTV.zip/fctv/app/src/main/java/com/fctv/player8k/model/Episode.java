package com.fctv.player8k.model;

public class Episode {
    public String id;
    public String title;
    public String url;
    public String plot = "";
    public String cover = "";
    public int season;
    public int number;
    public int durationSeconds;

    public String key(String playlistId, String seriesId) {
        return playlistId + "|episode|" + seriesId + "|" + id;
    }

    public String label() {
        return "S" + pad(season) + "E" + pad(number) + "  " + title;
    }

    private static String pad(int n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }
}

package com.fctv.player8k.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fctv.player8k.R;

import java.util.ArrayList;
import java.util.List;

public class SeasonAdapter extends RecyclerView.Adapter<SeasonAdapter.VH> {

    private final List<Integer> seasons = new ArrayList<>();
    private final Click<Integer> onClick;
    private int selected = 0;

    public SeasonAdapter(Click<Integer> onClick) {
        this.onClick = onClick;
    }

    public void submit(List<Integer> list) {
        seasons.clear();
        if (list != null) seasons.addAll(list);
        selected = 0;
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_season, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final Integer season = seasons.get(position);
        h.label.setText("Season " + season);
        h.itemView.setSelected(position == selected);
        h.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int pos = h.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) return;
                int old = selected;
                selected = pos;
                notifyItemChanged(old);
                notifyItemChanged(pos);
                onClick.on(season, pos);
            }
        });
    }

    @Override public int getItemCount() { return seasons.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView label;
        VH(View v) {
            super(v);
            label = (TextView) v;
        }
    }
}

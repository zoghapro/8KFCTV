package com.fctv.player8k.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class SeriesDetail {
    public String plot = "";
    public String cover = "";
    public String cast = "";
    public String genre = "";
    public String releaseDate = "";
    public String rating = "";
    /** Season number -> episodes, in season order. */
    public final Map<Integer, List<Episode>> seasons = new LinkedHashMap<>();

    public List<Integer> seasonNumbers() {
        return new ArrayList<>(seasons.keySet());
    }

    public List<Episode> episodesOf(int season) {
        List<Episode> l = seasons.get(season);
        return l != null ? l : new ArrayList<Episode>();
    }
}

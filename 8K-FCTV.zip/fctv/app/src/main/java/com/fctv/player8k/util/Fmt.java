package com.fctv.player8k.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class Fmt {
    private Fmt() {}

    private static final SimpleDateFormat CLOCK = new SimpleDateFormat("HH:mm", Locale.US);
    private static final SimpleDateFormat DAY = new SimpleDateFormat("EEE d MMM", Locale.US);

    public static String clock(long millis) { return CLOCK.format(new Date(millis)); }

    public static String day(long millis) { return DAY.format(new Date(millis)); }

    /** 5025000 -> "1:23:45"; under an hour -> "23:45". */
    public static String duration(long millis) {
        if (millis <= 0) return "0:00";
        long total = millis / 1000;
        long h = total / 3600;
        long m = (total % 3600) / 60;
        long s = total % 60;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d", h, m, s);
        return String.format(Locale.US, "%d:%02d", m, s);
    }

    public static boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }

    public static String orDash(String s) { return isBlank(s) ? "—" : s.trim(); }
}

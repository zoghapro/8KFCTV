package com.fctv.player8k.ui.adapter;

/** Small callback so adapters do not need java.util.function (API 24+). */
public interface Click<T> {
    void on(T item, int position);
}

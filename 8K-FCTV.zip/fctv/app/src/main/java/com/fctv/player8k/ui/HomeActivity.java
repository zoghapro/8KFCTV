package com.fctv.player8k.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.fctv.player8k.R;
import com.fctv.player8k.data.Repo;
import com.fctv.player8k.data.Store;
import com.fctv.player8k.model.MediaEntry;
import com.fctv.player8k.model.Playlist;
import com.fctv.player8k.util.Fmt;

/** The launcher screen: sections, the active playlist, and a clock. */
public class HomeActivity extends Activity {

    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private TextView clock, date;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            long now = System.currentTimeMillis();
            clock.setText(Fmt.clock(now));
            date.setText(Fmt.day(now));
            clockHandler.postDelayed(this, 30_000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_home);

        clock = findViewById(R.id.home_clock);
        date = findViewById(R.id.home_date);

        View live = findViewById(R.id.tile_live);
        View movies = findViewById(R.id.tile_movies);
        View series = findViewById(R.id.tile_series);
        View favorites = findViewById(R.id.tile_favorites);
        View playlists = findViewById(R.id.tile_playlists);
        View settings = findViewById(R.id.tile_settings);

        tile(live, R.drawable.ic_live, getString(R.string.live_tv), "Channels and EPG");
        tile(movies, R.drawable.ic_movie, getString(R.string.movies), "On demand");
        tile(series, R.drawable.ic_series, getString(R.string.series), "Seasons and episodes");
        tile(favorites, R.drawable.ic_star, getString(R.string.favorites), "Your saved channels");
        tile(playlists, R.drawable.ic_playlist, "Playlists", "Switch or add a source");
        tile(settings, R.drawable.ic_settings, getString(R.string.settings), "PIN and cache");

        live.setOnClickListener(open(MediaEntry.LIVE, false));
        movies.setOnClickListener(open(MediaEntry.MOVIE, false));
        series.setOnClickListener(open(MediaEntry.SERIES, false));
        favorites.setOnClickListener(open(MediaEntry.LIVE, true));

        playlists.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, PlaylistsActivity.class));
            }
        });
        settings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, SettingsActivity.class));
            }
        });

        live.requestFocus();
    }

    private void tile(View root, int icon, String title, String subtitle) {
        ((ImageView) root.findViewById(R.id.tile_icon)).setImageResource(icon);
        ((TextView) root.findViewById(R.id.tile_title)).setText(title);
        ((TextView) root.findViewById(R.id.tile_sub)).setText(subtitle);
    }

    private View.OnClickListener open(final String type, final boolean favoritesOnly) {
        return new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(HomeActivity.this, CatalogActivity.class);
                i.putExtra(CatalogActivity.EXTRA_TYPE, type);
                i.putExtra(CatalogActivity.EXTRA_FAVORITES, favoritesOnly);
                startActivity(i);
            }
        };
    }

    @Override protected void onResume() {
        super.onResume();

        Playlist p = Repo.get().active();
        TextView label = findViewById(R.id.home_playlist);
        if (p == null) {
            label.setText("No playlist selected");
        } else {
            String name = p.name == null || p.name.isEmpty() ? "Playlist" : p.name;
            label.setText(p.expiryLabel.isEmpty() ? name : name + "  ·  " + p.expiryLabel);
        }

        // If the user deleted the active playlist while away, go back to setup.
        if (Store.get(this).activePlaylist() == null) {
            startActivity(new Intent(this, PlaylistsActivity.class));
            finish();
            return;
        }

        clockHandler.removeCallbacks(tick);
        clockHandler.post(tick);
    }

    @Override protected void onPause() {
        super.onPause();
        clockHandler.removeCallbacks(tick);
    }
}

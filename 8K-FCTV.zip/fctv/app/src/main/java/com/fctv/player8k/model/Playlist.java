package com.fctv.player8k.model;

import org.json.JSONException;
import org.json.JSONObject;

/** A saved source of content: either Xtream Codes credentials or a plain M3U URL. */
public class Playlist {
    public static final String TYPE_XTREAM = "xtream";
    public static final String TYPE_M3U = "m3u";

    public String id;
    public String name;
    public String type;
    public String server;   // xtream base, e.g. http://host:8080
    public String username;
    public String password;
    public String m3uUrl;
    public String epgUrl;
    public long addedAt;

    /** Filled in after a successful Xtream login; purely informational. */
    public String expiryLabel = "";

    public Playlist() {}

    public boolean isXtream() { return TYPE_XTREAM.equals(type); }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("type", type);
        o.put("server", server);
        o.put("username", username);
        o.put("password", password);
        o.put("m3uUrl", m3uUrl);
        o.put("epgUrl", epgUrl);
        o.put("addedAt", addedAt);
        return o;
    }

    public static Playlist fromJson(JSONObject o) {
        Playlist p = new Playlist();
        p.id = o.optString("id");
        p.name = o.optString("name");
        p.type = o.optString("type", TYPE_M3U);
        p.server = o.optString("server");
        p.username = o.optString("username");
        p.password = o.optString("password");
        p.m3uUrl = o.optString("m3uUrl");
        p.epgUrl = o.optString("epgUrl");
        p.addedAt = o.optLong("addedAt");
        return p;
    }
}

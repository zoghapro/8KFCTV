package com.fctv.player8k.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fctv.player8k.R;
import com.fctv.player8k.model.MediaEntry;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Row layout used for live channels: logo, name, favorite marker. */
public class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.VH> {

    private final List<MediaEntry> items = new ArrayList<>();
    private final Click<MediaEntry> onClick;
    private final Click<MediaEntry> onLongClick;
    private Set<String> favoriteKeys = new HashSet<>();
    private String playlistId = "";

    public ChannelAdapter(Click<MediaEntry> onClick, Click<MediaEntry> onLongClick) {
        this.onClick = onClick;
        this.onLongClick = onLongClick;
    }

    public void setFavorites(String playlistId, Set<String> keys) {
        this.playlistId = playlistId == null ? "" : playlistId;
        this.favoriteKeys = keys != null ? keys : new HashSet<String>();
    }

    public void submit(List<MediaEntry> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    public List<MediaEntry> items() { return items; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_channel, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final MediaEntry e = items.get(position);
        h.name.setText(e.name);
        h.fav.setVisibility(favoriteKeys.contains(e.key(playlistId)) ? View.VISIBLE : View.GONE);

        if (e.logo != null && !e.logo.isEmpty()) {
            Glide.with(h.logo.getContext())
                    .load(e.logo)
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder)
                    .into(h.logo);
        } else {
            Glide.with(h.logo.getContext()).clear(h.logo);
            h.logo.setImageResource(R.drawable.ic_placeholder);
        }

        h.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int pos = h.getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) onClick.on(e, pos);
            }
        });
        h.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                int pos = h.getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) onLongClick.on(e, pos);
                return true;
            }
        });
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView name, epg;
        final ImageView logo, fav;
        VH(View v) {
            super(v);
            name = v.findViewById(R.id.ch_name);
            epg = v.findViewById(R.id.ch_epg);
            logo = v.findViewById(R.id.ch_logo);
            fav = v.findViewById(R.id.ch_fav);
        }
    }
}

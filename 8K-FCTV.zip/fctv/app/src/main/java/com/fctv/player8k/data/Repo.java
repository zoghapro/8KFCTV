package com.fctv.player8k.data;

import android.content.Context;

import com.fctv.player8k.model.Category;
import com.fctv.player8k.model.MediaEntry;
import com.fctv.player8k.model.Playlist;
import com.fctv.player8k.util.Task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * In-memory cache for the active playlist. Listings are fetched once per section
 * and reused, so moving between categories does not hit the network again.
 */
public class Repo {

    private static Repo instance;

    public static synchronized Repo get() {
        if (instance == null) instance = new Repo();
        return instance;
    }

    private Playlist active;
    private XtreamClient xtream;

    private final Map<String, List<MediaEntry>> entriesByType = new HashMap<>();
    private final Map<String, List<Category>> categoriesByType = new HashMap<>();

    /** The channel list the player is currently zapping through. */
    private List<MediaEntry> playbackQueue = new ArrayList<>();

    public void setActive(Playlist p) {
        if (active != null && p != null && active.id.equals(p.id)) {
            active = p;
            return;
        }
        active = p;
        xtream = (p != null && p.isXtream()) ? new XtreamClient(p) : null;
        entriesByType.clear();
        categoriesByType.clear();
        playbackQueue = new ArrayList<>();
    }

    public Playlist active() { return active; }

    public XtreamClient xtream() { return xtream; }

    public boolean isLoaded(String type) { return entriesByType.containsKey(type); }

    public List<MediaEntry> entries(String type) {
        List<MediaEntry> l = entriesByType.get(type);
        return l != null ? l : new ArrayList<MediaEntry>();
    }

    public List<Category> categories(String type) {
        List<Category> l = categoriesByType.get(type);
        return l != null ? l : new ArrayList<Category>();
    }

    public void setPlaybackQueue(List<MediaEntry> queue) {
        playbackQueue = queue != null ? new ArrayList<>(queue) : new ArrayList<MediaEntry>();
    }

    public List<MediaEntry> playbackQueue() { return playbackQueue; }

    // ---------- loading ----------

    public interface Loaded { void ok(); void fail(String message); }

    /** Loads one section (live / movie / series) for the active playlist. */
    public void load(final Context ctx, final String type, final Loaded cb) {
        if (active == null) { cb.fail("No playlist selected"); return; }
        if (isLoaded(type)) { cb.ok(); return; }

        Task.run(new Task.Work<Boolean>() {
            @Override public Boolean run() throws Exception {
                if (active.isXtream()) loadXtream(type);
                else loadM3u(type);
                return Boolean.TRUE;
            }
        }, new Task.Done<Boolean>() {
            @Override public void onSuccess(Boolean result) { cb.ok(); }
            @Override public void onError(Exception e) { cb.fail(readable(e)); }
        });
    }

    private void loadXtream(String type) throws Exception {
        List<Category> cats = xtream.categories(type);
        List<MediaEntry> entries = xtream.streams(type);

        Map<String, Category> byId = new LinkedHashMap<>();
        for (Category c : cats) byId.put(c.id, c);
        for (MediaEntry e : entries) {
            Category c = byId.get(e.categoryId);
            if (c != null) c.count++;
        }

        List<Category> ordered = new ArrayList<>();
        for (Category c : byId.values()) if (c.count > 0) ordered.add(c);

        categoriesByType.put(type, ordered);
        entriesByType.put(type, entries);
    }

    /** An M3U has no sections, so live and movie are split out of one fetch. */
    private void loadM3u(String type) throws Exception {
        if (!entriesByType.containsKey("__m3u__")) {
            String body = com.fctv.player8k.util.Http.getString(active.m3uUrl.trim());
            M3uParser.Result parsed = M3uParser.parse(body);
            if (parsed.entries.isEmpty()) throw new Exception("That playlist has no channels in it");
            entriesByType.put("__m3u__", parsed.entries);
            categoriesByType.put("__m3u__", parsed.categories);
        }

        List<MediaEntry> all = entriesByType.get("__m3u__");
        List<MediaEntry> filtered = new ArrayList<>();
        for (MediaEntry e : all) if (type.equals(e.type)) filtered.add(e);

        Map<String, Category> cats = new LinkedHashMap<>();
        for (MediaEntry e : filtered) {
            Category c = cats.get(e.categoryId);
            if (c == null) {
                c = new Category(e.categoryId, e.categoryId);
                cats.put(e.categoryId, c);
            }
            c.count++;
        }

        entriesByType.put(type, filtered);
        categoriesByType.put(type, new ArrayList<>(cats.values()));
    }

    public void invalidate() {
        entriesByType.clear();
        categoriesByType.clear();
    }

    // ---------- querying ----------

    public List<MediaEntry> filter(String type, String categoryId, String query) {
        List<MediaEntry> source = entries(type);
        List<MediaEntry> out = new ArrayList<>();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.US);

        for (MediaEntry e : source) {
            if (categoryId != null
                    && !Category.ALL_ID.equals(categoryId)
                    && !categoryId.equals(e.categoryId)) continue;
            if (!q.isEmpty() && !e.name.toLowerCase(Locale.US).contains(q)) continue;
            out.add(e);
        }
        return out;
    }

    public List<MediaEntry> favorites(String type, java.util.Set<String> favoriteKeys) {
        List<MediaEntry> out = new ArrayList<>();
        if (active == null) return out;
        for (MediaEntry e : entries(type)) {
            if (favoriteKeys.contains(e.key(active.id))) out.add(e);
        }
        return out;
    }

    public MediaEntry findById(String type, String id) {
        for (MediaEntry e : entries(type)) if (e.id.equals(id)) return e;
        return null;
    }

    /** Network errors are usually opaque; give the user something they can act on. */
    public static String readable(Exception e) {
        String m = e.getMessage();
        if (m == null || m.isEmpty()) m = e.getClass().getSimpleName();
        String lower = m.toLowerCase(Locale.US);
        if (lower.contains("unable to resolve host") || lower.contains("unknownhost")) {
            return "Cannot reach that server. Check the address and your connection.";
        }
        if (lower.contains("timed out") || lower.contains("timeout")) {
            return "The server took too long to answer. Try again.";
        }
        if (lower.contains("returned 401") || lower.contains("returned 403")) {
            return "The server rejected these credentials.";
        }
        if (lower.contains("returned 404")) {
            return "That address is not an Xtream panel or the path is wrong.";
        }
        if (lower.contains("json")) {
            return "The server sent something this app could not read.";
        }
        return m;
    }
}

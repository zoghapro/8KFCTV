package com.fctv.player8k.ui;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import com.bumptech.glide.Glide;
import com.fctv.player8k.R;
import com.fctv.player8k.data.Repo;
import com.fctv.player8k.data.Store;
import com.fctv.player8k.data.XtreamClient;
import com.fctv.player8k.model.EpgProgram;
import com.fctv.player8k.model.MediaEntry;
import com.fctv.player8k.util.Fmt;
import com.fctv.player8k.util.Http;
import com.fctv.player8k.util.Task;

import java.util.List;

@UnstableApi
public class PlayerActivity extends Activity {

    public static final String EXTRA_URL = "url";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_LOGO = "logo";
    public static final String EXTRA_LIVE = "live";
    public static final String EXTRA_STREAM_ID = "stream_id";
    public static final String EXTRA_QUEUE_INDEX = "queue_index";
    public static final String EXTRA_RESUME_KEY = "resume_key";
    public static final String EXTRA_RESUME_AT = "resume_at";

    private static final int[] RESIZE_MODES = {
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_FILL,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    };
    private static final String[] RESIZE_LABELS = { "Fit", "Stretch", "Zoom" };

    private static final long BANNER_MS = 5000;

    private ExoPlayer player;
    private PlayerView playerView;
    private Store store;

    private View banner, loading, errorPane;
    private TextView titleView, nowView, nextView, statusView, errorText;
    private ProgressBar epgProgress;
    private ImageView logoView;

    private final Handler ui = new Handler(Looper.getMainLooper());

    private String url, title, logo, streamId, resumeKey;
    private boolean live;
    private long resumeAt;
    private int queueIndex = -1;
    private boolean triedAlternate;

    private final Runnable hideBanner = new Runnable() {
        @Override public void run() { banner.setVisibility(View.GONE); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_player);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        store = Store.get(this);

        playerView = findViewById(R.id.pl_video);
        banner = findViewById(R.id.pl_banner);
        loading = findViewById(R.id.pl_loading);
        errorPane = findViewById(R.id.pl_error);
        titleView = findViewById(R.id.pl_title);
        nowView = findViewById(R.id.pl_now);
        nextView = findViewById(R.id.pl_next);
        statusView = findViewById(R.id.pl_status);
        errorText = findViewById(R.id.pl_error_text);
        epgProgress = findViewById(R.id.pl_progress);
        logoView = findViewById(R.id.pl_logo);

        findViewById(R.id.pl_retry).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                triedAlternate = false;
                startPlayback();
            }
        });

        readIntent(getIntent().getExtras());
    }

    private void readIntent(Bundle extras) {
        if (extras == null) return;
        url = extras.getString(EXTRA_URL);
        title = extras.getString(EXTRA_TITLE, "");
        logo = extras.getString(EXTRA_LOGO, "");
        live = extras.getBoolean(EXTRA_LIVE, false);
        streamId = extras.getString(EXTRA_STREAM_ID, "");
        resumeKey = extras.getString(EXTRA_RESUME_KEY, "");
        resumeAt = extras.getLong(EXTRA_RESUME_AT, 0L);
        queueIndex = extras.getInt(EXTRA_QUEUE_INDEX, -1);
    }

    private void buildPlayer() {
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(Http.USER_AGENT)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(30000)
                .setAllowCrossProtocolRedirects(true);

        // Live streams benefit from a deeper buffer; IPTV feeds are often bursty.
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                        live ? 20000 : 15000,
                        live ? 90000 : 60000,
                        2500,
                        5000)
                .build();

        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http))
                .setLoadControl(loadControl)
                .build();

        playerView.setPlayer(player);
        playerView.setResizeMode(RESIZE_MODES[clampMode(store.aspectMode())]);
        playerView.setControllerShowTimeoutMs(live ? 3000 : 5000);
        playerView.setUseController(!live);

        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    loading.setVisibility(View.GONE);
                    errorPane.setVisibility(View.GONE);
                } else if (state == Player.STATE_BUFFERING) {
                    statusView.setText("Buffering…");
                }
            }
            @Override public void onPlayerError(PlaybackException error) {
                handleError(error);
            }
        });
    }

    private void startPlayback() {
        if (player == null) return;
        if (url == null || url.isEmpty()) {
            showError("This item has no playable address.");
            return;
        }

        loading.setVisibility(View.VISIBLE);
        errorPane.setVisibility(View.GONE);
        statusView.setText(getString(R.string.loading));

        player.setMediaItem(MediaItem.fromUri(url));
        player.prepare();
        if (!live && resumeAt > 0) player.seekTo(resumeAt);
        player.setPlayWhenReady(true);

        titleView.setText(title);
        if (logo != null && !logo.isEmpty()) {
            Glide.with(this).load(logo)
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder)
                    .into(logoView);
        } else {
            logoView.setImageResource(R.drawable.ic_placeholder);
        }

        if (live) {
            showBanner();
            loadEpg();
        }
    }

    /** Panels vary in whether they serve .ts or .m3u8, so retry the other form once. */
    private void handleError(PlaybackException error) {
        if (live && !triedAlternate) {
            String alternate = XtreamClient.alternateLiveUrl(url);
            if (alternate != null) {
                triedAlternate = true;
                url = alternate;
                startPlayback();
                return;
            }
        }
        showError("This stream would not start.\n" + friendly(error));
    }

    private static String friendly(PlaybackException e) {
        String name = e.getErrorCodeName();
        if (name.contains("IO_BAD_HTTP_STATUS")) return "The server refused the request.";
        if (name.contains("IO_NETWORK") || name.contains("IO_UNSPECIFIED")) {
            return "The connection dropped. Check your network.";
        }
        if (name.contains("DECODER")) return "This device cannot decode that format.";
        if (name.contains("PARSING")) return "The stream format was not readable.";
        return "Error: " + name;
    }

    private void showError(String message) {
        loading.setVisibility(View.GONE);
        errorPane.setVisibility(View.VISIBLE);
        errorText.setText(message);
        findViewById(R.id.pl_retry).requestFocus();
    }

    // ---------- EPG ----------

    private void loadEpg() {
        nowView.setText("");
        nextView.setText("");
        epgProgress.setProgress(0);

        if (Repo.get().xtream() == null || streamId == null || streamId.isEmpty()) return;

        final String forStream = streamId;
        Task.run(new Task.Work<List<EpgProgram>>() {
            @Override public List<EpgProgram> run() throws Exception {
                return Repo.get().xtream().shortEpg(forStream);
            }
        }, new Task.Done<List<EpgProgram>>() {
            @Override public void onSuccess(List<EpgProgram> programs) {
                // The user may have zapped away while this was in flight.
                if (!forStream.equals(streamId)) return;
                bindEpg(programs);
            }
            @Override public void onError(Exception e) { /* EPG is optional */ }
        });
    }

    private void bindEpg(List<EpgProgram> programs) {
        if (programs == null || programs.isEmpty()) return;
        long now = System.currentTimeMillis();

        EpgProgram current = programs.get(0);
        nowView.setText(Fmt.clock(current.startMillis) + "  " + current.title);
        epgProgress.setProgress((int) (current.progressAt(now) * 100));

        if (programs.size() > 1) {
            EpgProgram next = programs.get(1);
            nextView.setText("Next  " + Fmt.clock(next.startMillis) + "  " + next.title);
        }
    }

    private void showBanner() {
        banner.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideBanner);
        ui.postDelayed(hideBanner, BANNER_MS);
    }

    // ---------- channel zapping ----------

    private void zap(int delta) {
        List<MediaEntry> queue = Repo.get().playbackQueue();
        if (queue.isEmpty() || queueIndex < 0) return;

        int next = (queueIndex + delta) % queue.size();
        if (next < 0) next += queue.size();

        MediaEntry entry = queue.get(next);
        queueIndex = next;
        url = entry.url;
        title = entry.name;
        logo = entry.logo;
        streamId = entry.id;
        triedAlternate = false;

        startPlayback();
    }

    private void cycleAspect() {
        int mode = clampMode(store.aspectMode() + 1);
        store.setAspectMode(mode);
        playerView.setResizeMode(RESIZE_MODES[mode]);
        titleView.setText(title + "  ·  " + RESIZE_LABELS[mode]);
        showBanner();
    }

    private static int clampMode(int mode) {
        if (mode < 0 || mode >= RESIZE_MODES.length) return 0;
        return mode;
    }

    // ---------- remote control ----------

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_CHANNEL_UP:
                if (live) { zap(-1); return true; }
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_CHANNEL_DOWN:
                if (live) { zap(1); return true; }
                break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (live) { showBanner(); return true; }
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (!live && player != null) {
                    player.seekTo(player.getCurrentPosition() + 30_000);
                    return true;
                }
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (!live && player != null) {
                    player.seekTo(Math.max(0, player.getCurrentPosition() - 10_000));
                    return true;
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_SPACE:
                if (player != null) player.setPlayWhenReady(!player.getPlayWhenReady());
                return true;
            case KeyEvent.KEYCODE_INFO:
            case KeyEvent.KEYCODE_MENU:
                cycleAspect();
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    // ---------- lifecycle ----------

    private void saveResume() {
        if (live || player == null || resumeKey == null || resumeKey.isEmpty()) return;
        store.setResume(resumeKey, player.getCurrentPosition(), player.getDuration());
    }

    /**
     * The player is built in onStart and released in onStop, so returning from the
     * background rebuilds it and picks up where the stream left off rather than
     * showing a dead surface.
     */
    @Override protected void onStart() {
        super.onStart();
        if (player == null) {
            buildPlayer();
            startPlayback();
        }
    }

    @Override protected void onStop() {
        super.onStop();
        saveResume();
        ui.removeCallbacks(hideBanner);
        if (player != null) {
            // Live streams rejoin at the edge; on-demand picks up where we stopped.
            if (!live) resumeAt = player.getCurrentPosition();
            player.release();
            player = null;
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}

package com.fctv.player8k.model;

public class Category {
    public static final String ALL_ID = "__all__";
    public static final String FAV_ID = "__fav__";

    public final String id;
    public final String name;
    public int count;

    public Category(String id, String name) {
        this.id = id;
        this.name = name;
    }
}

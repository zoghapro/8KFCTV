package com.fctv.player8k.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fctv.player8k.R;
import com.fctv.player8k.model.Episode;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EpisodeAdapter extends RecyclerView.Adapter<EpisodeAdapter.VH> {

    private final List<Episode> items = new ArrayList<>();
    private final Click<Episode> onClick;
    private Set<String> resumeKeys = new HashSet<>();
    private String playlistId = "", seriesId = "";

    public EpisodeAdapter(Click<Episode> onClick) {
        this.onClick = onClick;
    }

    public void setResumeContext(String playlistId, String seriesId, Set<String> resumeKeys) {
        this.playlistId = playlistId;
        this.seriesId = seriesId;
        this.resumeKeys = resumeKeys != null ? resumeKeys : new HashSet<String>();
    }

    public void submit(List<Episode> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_episode, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final Episode ep = items.get(position);
        h.title.setText(ep.label());
        boolean partial = resumeKeys.contains(ep.key(playlistId, seriesId));
        h.badge.setVisibility(partial ? View.VISIBLE : View.GONE);
        h.badge.setText("Continue");

        h.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int pos = h.getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) onClick.on(ep, pos);
            }
        });
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView title, badge;
        VH(View v) {
            super(v);
            title = v.findViewById(R.id.ep_title);
            badge = v.findViewById(R.id.ep_badge);
        }
    }
}

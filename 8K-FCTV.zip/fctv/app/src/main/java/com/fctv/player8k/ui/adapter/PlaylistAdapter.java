package com.fctv.player8k.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fctv.player8k.R;
import com.fctv.player8k.model.Playlist;

import java.util.ArrayList;
import java.util.List;

public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.VH> {

    private final List<Playlist> items = new ArrayList<>();
    private final Click<Playlist> onOpen;
    private final Click<Playlist> onDelete;

    public PlaylistAdapter(Click<Playlist> onOpen, Click<Playlist> onDelete) {
        this.onOpen = onOpen;
        this.onDelete = onDelete;
    }

    public void submit(List<Playlist> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_playlist, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final Playlist p = items.get(position);
        h.name.setText(p.name == null || p.name.isEmpty() ? "Untitled playlist" : p.name);
        h.detail.setText(p.isXtream() ? hostOf(p.server) : hostOf(p.m3uUrl));

        h.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int pos = h.getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) onOpen.on(p, pos);
            }
        });
        h.delete.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int pos = h.getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) onDelete.on(p, pos);
            }
        });
    }

    /** Show the host only - credentials never belong on screen. */
    private static String hostOf(String url) {
        if (url == null || url.isEmpty()) return "";
        try {
            java.net.URL u = new java.net.URL(
                    url.startsWith("http") ? url : "http://" + url);
            String host = u.getHost();
            return u.getPort() > 0 ? host + ":" + u.getPort() : host;
        } catch (Exception e) {
            return url;
        }
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView name, detail;
        final View delete;
        VH(View v) {
            super(v);
            name = v.findViewById(R.id.pl_name);
            detail = v.findViewById(R.id.pl_detail);
            delete = v.findViewById(R.id.pl_delete);
        }
    }
}

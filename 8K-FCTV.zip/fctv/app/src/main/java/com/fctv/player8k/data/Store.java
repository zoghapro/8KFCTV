package com.fctv.player8k.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.fctv.player8k.model.Playlist;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Everything that survives a restart: playlists, favorites, resume points, settings. */
public class Store {
    private static final String FILE = "fctv_store";
    private static final String K_PLAYLISTS = "playlists";
    private static final String K_ACTIVE = "active_playlist";
    private static final String K_FAVORITES = "favorites";
    private static final String K_RESUME = "resume";
    private static final String K_PIN = "parental_pin";
    private static final String K_LOCKED_CATS = "locked_categories";
    private static final String K_ASPECT = "aspect_mode";
    private static final String K_LAST_CHANNEL = "last_channel";

    private static Store instance;
    private final SharedPreferences prefs;

    private Store(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static synchronized Store get(Context ctx) {
        if (instance == null) instance = new Store(ctx);
        return instance;
    }

    // ---------- playlists ----------

    public List<Playlist> playlists() {
        List<Playlist> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs.getString(K_PLAYLISTS, "[]"));
            for (int i = 0; i < a.length(); i++) out.add(Playlist.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {}
        return out;
    }

    public void savePlaylist(Playlist p) {
        if (p.id == null || p.id.isEmpty()) p.id = UUID.randomUUID().toString();
        if (p.addedAt == 0) p.addedAt = System.currentTimeMillis();
        List<Playlist> all = playlists();
        boolean replaced = false;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(p.id)) { all.set(i, p); replaced = true; break; }
        }
        if (!replaced) all.add(p);
        writePlaylists(all);
    }

    public void deletePlaylist(String id) {
        List<Playlist> all = playlists();
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(id)) { all.remove(i); break; }
        }
        writePlaylists(all);
        if (id.equals(activePlaylistId())) {
            prefs.edit().remove(K_ACTIVE).apply();
        }
        clearScoped(id);
    }

    private void writePlaylists(List<Playlist> all) {
        try {
            JSONArray a = new JSONArray();
            for (Playlist p : all) a.put(p.toJson());
            prefs.edit().putString(K_PLAYLISTS, a.toString()).apply();
        } catch (Exception ignored) {}
    }

    public String activePlaylistId() { return prefs.getString(K_ACTIVE, null); }

    public void setActivePlaylist(String id) { prefs.edit().putString(K_ACTIVE, id).apply(); }

    public Playlist activePlaylist() {
        String id = activePlaylistId();
        if (id == null) return null;
        for (Playlist p : playlists()) if (p.id.equals(id)) return p;
        return null;
    }

    // ---------- favorites ----------

    public Set<String> favorites() {
        return new HashSet<>(prefs.getStringSet(K_FAVORITES, new HashSet<String>()));
    }

    public boolean isFavorite(String key) { return favorites().contains(key); }

    public void toggleFavorite(String key) {
        Set<String> f = favorites();
        if (!f.remove(key)) f.add(key);
        prefs.edit().putStringSet(K_FAVORITES, f).apply();
    }

    // ---------- resume points ----------

    public void setResume(String key, long positionMs, long durationMs) {
        // Near the start or the end, there is nothing worth resuming.
        if (positionMs < 30_000 || (durationMs > 0 && positionMs > durationMs - 60_000)) {
            clearResume(key);
            return;
        }
        try {
            JSONObject o = resumeMap();
            o.put(key, positionMs);
            prefs.edit().putString(K_RESUME, o.toString()).apply();
        } catch (Exception ignored) {}
    }

    public long resume(String key) {
        return resumeMap().optLong(key, 0L);
    }

    public void clearResume(String key) {
        JSONObject o = resumeMap();
        o.remove(key);
        prefs.edit().putString(K_RESUME, o.toString()).apply();
    }

    public void clearAllResume() {
        prefs.edit().putString(K_RESUME, "{}").apply();
    }

    private JSONObject resumeMap() {
        try {
            return new JSONObject(prefs.getString(K_RESUME, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private void clearScoped(String playlistId) {
        Set<String> f = favorites();
        Set<String> keep = new HashSet<>();
        for (String k : f) if (!k.startsWith(playlistId + "|")) keep.add(k);
        prefs.edit().putStringSet(K_FAVORITES, keep).apply();
    }

    // ---------- parental lock ----------

    public String pin() { return prefs.getString(K_PIN, ""); }

    public void setPin(String pin) { prefs.edit().putString(K_PIN, pin == null ? "" : pin).apply(); }

    public boolean hasPin() { return !pin().isEmpty(); }

    public Set<String> lockedCategories() {
        return new HashSet<>(prefs.getStringSet(K_LOCKED_CATS, new HashSet<String>()));
    }

    public boolean isLocked(String categoryId) {
        return hasPin() && lockedCategories().contains(categoryId);
    }

    public void toggleLocked(String categoryId) {
        Set<String> l = lockedCategories();
        if (!l.remove(categoryId)) l.add(categoryId);
        prefs.edit().putStringSet(K_LOCKED_CATS, l).apply();
    }

    // ---------- playback preferences ----------

    public int aspectMode() { return prefs.getInt(K_ASPECT, 0); }

    public void setAspectMode(int mode) { prefs.edit().putInt(K_ASPECT, mode).apply(); }

    public void setLastChannel(String key) { prefs.edit().putString(K_LAST_CHANNEL, key).apply(); }

    public String lastChannel() { return prefs.getString(K_LAST_CHANNEL, ""); }
}

package com.fctv.player8k.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.fctv.player8k.R;
import com.fctv.player8k.data.Repo;
import com.fctv.player8k.data.Store;
import com.fctv.player8k.model.MediaEntry;
import com.fctv.player8k.model.Playlist;

/** Decides where to send the user: playlist setup, or straight to Home. */
public class SplashActivity extends Activity {

    private TextView status;
    private Button retry;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_splash);
        status = findViewById(R.id.splash_status);
        retry = findViewById(R.id.splash_retry);
        retry.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { start(); }
        });
        start();
    }

    private void start() {
        retry.setVisibility(View.GONE);
        status.setText(R.string.checking);

        Playlist active = Store.get(this).activePlaylist();
        if (active == null) {
            go(PlaylistsActivity.class);
            return;
        }

        Repo.get().setActive(active);

        // Warm the first section so Home does not open onto an empty screen.
        Repo.get().load(this, MediaEntry.LIVE, new Repo.Loaded() {
            @Override public void ok() {
                go(HomeActivity.class);
            }
            @Override public void fail(String message) {
                status.setText(message);
                retry.setVisibility(View.VISIBLE);
                retry.requestFocus();
            }
        });
    }

    private void go(Class<?> target) {
        startActivity(new Intent(this, target));
        finish();
    }
}
